setwd("C:\\Users\\ACER\\Desktop\\IT24100988_lab_7")

##Exercise
#part 01
 punif(25, min = 0, max = 40, lower.tail = TRUE) - 
 punif(10, min = 0, max = 40, lower.tail = TRUE)

#part 02
 pexp(2, rate = 1/3, lower.tail = TRUE)
 
 
 

#part 03
 #1
  pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)
  
 #2
  qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)


  
  