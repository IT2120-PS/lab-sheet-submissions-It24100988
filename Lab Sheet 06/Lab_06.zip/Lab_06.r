setwd("C:\\Users\\ACER\\Desktop\\IT24100988_lab_6")
getwd()


##Question 01
#part 1 
#random variable X has binomial distribiuton with n = 50 and p = 0.85


#part 2
1-pbinom(46,50,0.85,lower.tail = TRUE)


##Question 02
#part 1
#number of customer calls in a call center on per hour

#part 2
#poisson distribution
#Here, randam variable x has poisson distribution with lambda = 12

#part 3
dpois(3,12)
